
#include <iostream>
#include "linkedList.h"

using namespace std;



int main() {
    LinkedList<int> L1;
//    LinkedList<int> L2;
//    L1.display();
    return 0;
}