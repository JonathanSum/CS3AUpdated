//
// Created by JonathanSum on 5/25/2019.
//

#include "Iterator.h"


template<class E>
Iterator<E>::Iterator() {
    current = nullptr;
}