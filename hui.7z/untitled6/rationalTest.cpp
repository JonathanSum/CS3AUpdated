#include <iostream>
#include "rational.h"

using namespace std;

int main()
{
    Rational r, r1;
    r.display();
    r.add(r1);
}
